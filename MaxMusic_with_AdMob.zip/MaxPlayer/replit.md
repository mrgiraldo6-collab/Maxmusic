# Overview

This is a full-stack music player application built with a modern web stack. The application allows users to upload, organize, and play audio files through a Spotify-inspired interface. It features a React frontend with TypeScript, an Express.js backend, and PostgreSQL database integration using Drizzle ORM. The application supports file uploads, playlist management, and real-time audio playback with a comprehensive music player interface.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React 18 with TypeScript and Vite as the build tool
- **UI Library**: Shadcn/ui components built on Radix UI primitives for accessible, customizable components
- **Styling**: Tailwind CSS with a custom design system featuring Spotify-inspired dark theme
- **State Management**: TanStack Query (React Query) for server state management and caching
- **Routing**: Wouter for lightweight client-side routing
- **Audio Handling**: Custom audio player hook using native HTML5 Audio API with support for play/pause, seeking, volume control, shuffle, and repeat modes

## Backend Architecture
- **Framework**: Express.js with TypeScript for type safety
- **API Design**: RESTful API structure with dedicated routes for tracks and playlists
- **File Upload**: Multer middleware for handling audio file uploads with validation for audio MIME types and file size limits (50MB)
- **Storage Strategy**: Currently implements in-memory storage with interface abstraction to allow easy migration to database persistence
- **Error Handling**: Centralized error handling middleware with proper HTTP status codes

## Database Design
- **ORM**: Drizzle ORM with PostgreSQL dialect for type-safe database operations
- **Schema**: Two main entities - tracks and playlists with proper relationships
- **Tracks Table**: Stores audio file metadata including title, artist, album, duration, file information, and timestamps
- **Playlists Table**: Manages user-created playlists with track references stored as arrays
- **Migration Strategy**: Drizzle Kit for database schema migrations and version control

## Component Architecture
- **File Upload Component**: Drag-and-drop interface with metadata extraction from audio files
- **Music Player Component**: Full-featured audio player with progress tracking, volume control, and playback modes
- **Playlist Management**: Table and grid view modes for displaying tracks with search functionality
- **Sidebar Navigation**: Playlist creation and management interface

## Authentication & Authorization
Currently not implemented but the architecture is prepared for future authentication integration with session-based or token-based authentication patterns.

# External Dependencies

## Core Framework Dependencies
- **@neondatabase/serverless**: PostgreSQL connection driver optimized for serverless environments
- **drizzle-orm**: Type-safe ORM for database operations with PostgreSQL support
- **express**: Web application framework for the backend API server
- **multer**: Middleware for handling multipart/form-data file uploads

## Frontend UI Dependencies
- **@radix-ui/***: Collection of accessible, unstyled UI primitives for building the component system
- **@tanstack/react-query**: Data fetching and caching library for efficient server state management
- **tailwindcss**: Utility-first CSS framework for styling
- **wouter**: Minimalist routing library for React applications

## Development & Build Tools
- **vite**: Fast build tool and development server with HMR support
- **typescript**: Type checking and compilation for both frontend and backend
- **drizzle-kit**: Database migration and introspection tool
- **esbuild**: Fast JavaScript bundler for production builds

## File Processing
- **date-fns**: Date manipulation library for timestamp formatting
- **zod**: Schema validation library used with Drizzle for type-safe data validation
- **class-variance-authority**: Utility for managing CSS class variants in components

## Replit Integration
- **@replit/vite-plugin-runtime-error-modal**: Development error overlay for better debugging experience
- **@replit/vite-plugin-cartographer**: Development tool for code navigation and project structure visualization

The application is designed with scalability in mind, using interface-based storage abstraction that allows easy migration from in-memory storage to persistent database storage. The modular component architecture and type-safe API design facilitate maintenance and feature additions.