import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Track } from "@shared/schema";
import Sidebar from "@/components/sidebar";
import FileUpload from "@/components/file-upload";
import PlaylistTable from "@/components/playlist-table";
import MusicPlayer from "@/components/music-player";
import { Search, ChevronLeft, ChevronRight, Bell, User, Grid3X3, List } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useAudioPlayer } from "@/hooks/use-audio-player";

export default function MusicPlayerPage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [viewMode, setViewMode] = useState<"grid" | "list">("list");
  
  const { data: tracks = [], isLoading } = useQuery<Track[]>({
    queryKey: ["/api/tracks"],
  });

  const audioPlayer = useAudioPlayer();

  const filteredTracks = tracks.filter(track =>
    track.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    track.artist?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    track.album?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="flex h-screen overflow-hidden bg-spotify-dark text-white font-inter">
      {/* Sidebar */}
      <Sidebar />
      
      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* MaxMusic Header - Inspired by your design */}
        <header className="bg-spotify-green p-4 text-center">
          <h1 className="text-2xl font-bold text-black">🎵 MaxMusic</h1>
        </header>
        
        {/* Navigation Bar */}
        <div className="bg-spotify-gray bg-opacity-90 backdrop-blur-sm p-4 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Button 
              variant="outline" 
              size="sm" 
              className="p-2 rounded-full bg-black bg-opacity-70 hover:bg-opacity-100 transition-all border-none"
              data-testid="button-back"
            >
              <ChevronLeft className="h-4 w-4 text-spotify-light-gray" />
            </Button>
            <Button 
              variant="outline" 
              size="sm" 
              className="p-2 rounded-full bg-black bg-opacity-70 hover:bg-opacity-100 transition-all border-none"
              data-testid="button-forward"
            >
              <ChevronRight className="h-4 w-4 text-spotify-light-gray" />
            </Button>
          </div>
          
          {/* Search Bar */}
          <div className="flex-1 max-w-md mx-8">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-spotify-light-gray h-4 w-4" />
              <Input
                type="text"
                placeholder="Buscar canciones, artistas o álbumes"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-white text-black rounded-full py-2 pl-10 pr-4 text-sm focus:outline-none focus:ring-2 focus:ring-spotify-green border-none"
                data-testid="input-search"
              />
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            <Button 
              variant="ghost" 
              size="sm" 
              className="text-spotify-light-gray hover:text-white transition-colors"
              data-testid="button-notifications"
            >
              <Bell className="h-5 w-5" />
            </Button>
            <div className="w-8 h-8 bg-spotify-green rounded-full flex items-center justify-center">
              <User className="h-4 w-4 text-black" />
            </div>
          </div>
        </div>
        
        {/* Content Area */}
        <main className="flex-1 overflow-y-auto p-6 pb-24">
          {/* Ad Space - Inspired by your MaxMusic design */}
          <section className="mb-8">
            <div className="bg-gray-800 rounded-lg p-4 text-center">
              <p className="text-gray-400 text-sm">Publicidad</p>
              <p className="text-xs text-gray-500 mt-1">Espacio reservado para anuncios</p>
            </div>
          </section>

          {/* Main Title */}
          <section className="mb-6">
            <h2 className="text-2xl font-bold text-center">Reproductor de Música</h2>
          </section>

          {/* File Upload Section */}
          <section className="mb-8">
            <h3 className="text-xl font-semibold mb-4">Sube tu música</h3>
            <FileUpload />
          </section>
          
          {/* Current Playlist */}
          <section>
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold">Tu biblioteca musical</h2>
              <div className="flex items-center space-x-4">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setViewMode("grid")}
                  className={`text-spotify-light-gray hover:text-white transition-colors ${
                    viewMode === "grid" ? "text-white" : ""
                  }`}
                  data-testid="button-grid-view"
                >
                  <Grid3X3 className="h-4 w-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setViewMode("list")}
                  className={`text-spotify-light-gray hover:text-white transition-colors ${
                    viewMode === "list" ? "text-white" : ""
                  }`}
                  data-testid="button-list-view"
                >
                  <List className="h-4 w-4" />
                </Button>
              </div>
            </div>
            
            <PlaylistTable 
              tracks={filteredTracks} 
              isLoading={isLoading}
              onTrackPlay={(track) => audioPlayer.loadTrack(track)}
              currentTrack={audioPlayer.currentTrack}
              viewMode={viewMode}
            />
          </section>
        </main>
      </div>
      
      {/* Music Player */}
      <MusicPlayer audioPlayer={audioPlayer} />
    </div>
  );
}
