import { useState, useRef, useEffect, useCallback } from "react";
import { Track } from "@shared/schema";
import { useQuery } from "@tanstack/react-query";

export function useAudioPlayer() {
  const [currentTrack, setCurrentTrack] = useState<Track | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(0.75);
  const [isShuffleOn, setIsShuffleOn] = useState(false);
  const [repeatMode, setRepeatMode] = useState<"off" | "one" | "all">("off");
  const [currentTrackIndex, setCurrentTrackIndex] = useState(0);

  const audioRef = useRef<HTMLAudioElement | null>(null);

  const { data: tracks = [] } = useQuery<Track[]>({
    queryKey: ["/api/tracks"],
  });

  // Initialize audio element
  useEffect(() => {
    if (!audioRef.current) {
      audioRef.current = new Audio();
      
      const audio = audioRef.current;
      
      audio.addEventListener("loadedmetadata", () => {
        setDuration(audio.duration);
      });
      
      audio.addEventListener("timeupdate", () => {
        setCurrentTime(audio.currentTime);
      });
      
      audio.addEventListener("ended", () => {
        handleTrackEnd();
      });
      
      audio.addEventListener("play", () => {
        setIsPlaying(true);
      });
      
      audio.addEventListener("pause", () => {
        setIsPlaying(false);
      });
    }
    
    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current.src = "";
      }
    };
  }, []);

  // Update volume when it changes
  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = volume;
    }
  }, [volume]);

  const handleTrackEnd = useCallback(() => {
    if (repeatMode === "one") {
      // Repeat current track
      seekTo(0);
      play();
    } else if (repeatMode === "all" || isShuffleOn) {
      nextTrack();
    } else {
      // Check if there's a next track
      const currentIndex = tracks.findIndex(track => track.id === currentTrack?.id);
      if (currentIndex < tracks.length - 1) {
        nextTrack();
      } else {
        // End of playlist
        setIsPlaying(false);
        seekTo(0);
      }
    }
  }, [repeatMode, isShuffleOn, currentTrack, tracks]);

  const loadTrack = useCallback((track: Track) => {
    if (audioRef.current) {
      audioRef.current.src = `/api/tracks/${track.id}/stream`;
      setCurrentTrack(track);
      setCurrentTime(0);
      
      const trackIndex = tracks.findIndex(t => t.id === track.id);
      setCurrentTrackIndex(trackIndex);
    }
  }, [tracks]);

  const play = useCallback(() => {
    if (audioRef.current && currentTrack) {
      audioRef.current.play().catch(console.error);
    }
  }, [currentTrack]);

  const pause = useCallback(() => {
    if (audioRef.current) {
      audioRef.current.pause();
    }
  }, []);

  const togglePlayPause = useCallback(() => {
    if (isPlaying) {
      pause();
    } else {
      play();
    }
  }, [isPlaying, play, pause]);

  const seekTo = useCallback((time: number) => {
    if (audioRef.current) {
      audioRef.current.currentTime = time;
      setCurrentTime(time);
    }
  }, []);

  const getNextTrackIndex = useCallback(() => {
    if (tracks.length === 0) return -1;
    
    if (isShuffleOn) {
      // Random track, but not the current one
      let randomIndex;
      do {
        randomIndex = Math.floor(Math.random() * tracks.length);
      } while (randomIndex === currentTrackIndex && tracks.length > 1);
      return randomIndex;
    } else {
      // Next track in order
      return (currentTrackIndex + 1) % tracks.length;
    }
  }, [tracks, isShuffleOn, currentTrackIndex]);

  const getPreviousTrackIndex = useCallback(() => {
    if (tracks.length === 0) return -1;
    
    if (isShuffleOn) {
      // For simplicity, just go to previous in order during shuffle
      return currentTrackIndex > 0 ? currentTrackIndex - 1 : tracks.length - 1;
    } else {
      return currentTrackIndex > 0 ? currentTrackIndex - 1 : tracks.length - 1;
    }
  }, [tracks, isShuffleOn, currentTrackIndex]);

  const nextTrack = useCallback(() => {
    const nextIndex = getNextTrackIndex();
    if (nextIndex >= 0 && tracks[nextIndex]) {
      loadTrack(tracks[nextIndex]);
      if (isPlaying) {
        // Small delay to ensure track is loaded
        setTimeout(play, 100);
      }
    }
  }, [getNextTrackIndex, tracks, loadTrack, play, isPlaying]);

  const previousTrack = useCallback(() => {
    // If we're more than 3 seconds into the track, restart it
    if (currentTime > 3) {
      seekTo(0);
    } else {
      const prevIndex = getPreviousTrackIndex();
      if (prevIndex >= 0 && tracks[prevIndex]) {
        loadTrack(tracks[prevIndex]);
        if (isPlaying) {
          setTimeout(play, 100);
        }
      }
    }
  }, [currentTime, seekTo, getPreviousTrackIndex, tracks, loadTrack, play, isPlaying]);

  const toggleShuffle = useCallback(() => {
    setIsShuffleOn(prev => !prev);
  }, []);

  const toggleRepeat = useCallback(() => {
    setRepeatMode(prev => {
      switch (prev) {
        case "off": return "all";
        case "all": return "one";
        case "one": return "off";
        default: return "off";
      }
    });
  }, []);

  const setVolumeValue = useCallback((newVolume: number) => {
    setVolume(Math.max(0, Math.min(1, newVolume)));
  }, []);

  return {
    currentTrack,
    isPlaying,
    currentTime,
    duration,
    volume,
    isShuffleOn,
    repeatMode,
    play,
    pause,
    togglePlayPause,
    previousTrack,
    nextTrack,
    toggleShuffle,
    toggleRepeat,
    setVolume: setVolumeValue,
    seekTo,
    loadTrack,
  };
}
