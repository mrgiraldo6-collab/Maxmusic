import { Track } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Play, Heart, MoreHorizontal, Music } from "lucide-react";
import { formatDuration } from "@/lib/audio-utils";

interface PlaylistTableProps {
  tracks: Track[];
  isLoading: boolean;
  onTrackPlay: (track: Track) => void;
  currentTrack?: Track | null;
  viewMode: "grid" | "list";
}

export default function PlaylistTable({ 
  tracks, 
  isLoading, 
  onTrackPlay, 
  currentTrack,
  viewMode 
}: PlaylistTableProps) {
  if (isLoading) {
    return (
      <div className="space-y-4">
        {Array.from({ length: 5 }).map((_, i) => (
          <div key={i} className="grid grid-cols-12 gap-4 py-2 px-2 rounded">
            <div className="col-span-1 bg-spotify-gray rounded h-4 animate-pulse" />
            <div className="col-span-6 bg-spotify-gray rounded h-4 animate-pulse" />
            <div className="col-span-3 bg-spotify-gray rounded h-4 animate-pulse" />
            <div className="col-span-1 bg-spotify-gray rounded h-4 animate-pulse" />
            <div className="col-span-1 bg-spotify-gray rounded h-4 animate-pulse" />
          </div>
        ))}
      </div>
    );
  }

  if (tracks.length === 0) {
    return (
      <div className="text-center py-12" data-testid="empty-state">
        <Music className="mx-auto h-16 w-16 text-spotify-light-gray mb-4" />
        <h3 className="text-xl font-medium mb-2">No hay canciones en tu biblioteca</h3>
        <p className="text-spotify-light-gray mb-6">Sube algunos archivos de audio para comenzar</p>
      </div>
    );
  }

  if (viewMode === "grid") {
    return (
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        {tracks.map((track) => (
          <div
            key={track.id}
            className="bg-spotify-gray rounded-lg p-4 hover:bg-gray-700 transition-colors cursor-pointer group"
            onClick={() => onTrackPlay(track)}
            data-testid={`track-card-${track.id}`}
          >
            <div className="w-full aspect-square bg-gray-600 rounded mb-3 flex items-center justify-center relative">
              <Music className="h-8 w-8 text-spotify-light-gray" />
              <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-40 rounded flex items-center justify-center transition-all">
                <Play className="h-8 w-8 text-white opacity-0 group-hover:opacity-100 transition-opacity" />
              </div>
            </div>
            <h3 className="font-medium text-sm truncate" title={track.title}>
              {track.title}
            </h3>
            <p className="text-spotify-light-gray text-xs truncate" title={track.artist}>
              {track.artist || "Artista desconocido"}
            </p>
          </div>
        ))}
      </div>
    );
  }

  return (
    <div>
      {/* Table Header */}
      <div className="grid grid-cols-12 gap-4 text-spotify-light-gray text-sm font-medium mb-4 pb-2 border-b border-spotify-gray">
        <div className="col-span-1 text-center">#</div>
        <div className="col-span-6">TÍTULO</div>
        <div className="col-span-3">ÁLBUM</div>
        <div className="col-span-1">FECHA</div>
        <div className="col-span-1 text-center">
          <span className="sr-only">Duración</span>
          🕐
        </div>
      </div>
      
      {/* Track List */}
      <div className="space-y-1">
        {tracks.map((track, index) => (
          <div
            key={track.id}
            className={`grid grid-cols-12 gap-4 py-2 px-2 rounded hover:bg-spotify-gray hover:bg-opacity-50 transition-colors group cursor-pointer ${
              currentTrack?.id === track.id ? "bg-spotify-gray bg-opacity-30" : ""
            }`}
            onClick={() => onTrackPlay(track)}
            data-testid={`track-row-${track.id}`}
          >
            <div className="col-span-1 text-center text-spotify-light-gray group-hover:text-white flex items-center justify-center">
              <span className={`group-hover:hidden ${currentTrack?.id === track.id ? "text-spotify-green" : ""}`}>
                {index + 1}
              </span>
              <Play className="h-4 w-4 hidden group-hover:block" />
            </div>
            <div className="col-span-6 flex items-center">
              <div className="w-10 h-10 bg-gray-600 rounded mr-3 flex items-center justify-center">
                <Music className="h-4 w-4 text-spotify-light-gray" />
              </div>
              <div>
                <div className={`font-medium ${currentTrack?.id === track.id ? "text-spotify-green" : "text-white"}`}>
                  {track.title}
                </div>
                <div className="text-spotify-light-gray text-sm">
                  {track.artist || "Artista desconocido"}
                </div>
              </div>
            </div>
            <div className="col-span-3 flex items-center text-spotify-light-gray text-sm">
              {track.album || "Álbum desconocido"}
            </div>
            <div className="col-span-1 flex items-center text-spotify-light-gray text-sm">
              {track.createdAt ? new Date(track.createdAt).toLocaleDateString() : ""}
            </div>
            <div className="col-span-1 flex items-center justify-center">
              <div className="flex items-center space-x-2 opacity-0 group-hover:opacity-100 transition-opacity">
                <Button
                  variant="ghost"
                  size="sm"
                  className="text-spotify-light-gray hover:text-white p-1"
                  onClick={(e) => {
                    e.stopPropagation();
                    // TODO: Add to favorites
                  }}
                  data-testid={`button-favorite-${track.id}`}
                >
                  <Heart className="h-3 w-3" />
                </Button>
                <span className="text-spotify-light-gray text-sm">
                  {formatDuration(track.duration || 0)}
                </span>
                <Button
                  variant="ghost"
                  size="sm"
                  className="text-spotify-light-gray hover:text-white p-1"
                  onClick={(e) => {
                    e.stopPropagation();
                    // TODO: Show track menu
                  }}
                  data-testid={`button-menu-${track.id}`}
                >
                  <MoreHorizontal className="h-3 w-3" />
                </Button>
              </div>
              <span className="text-spotify-light-gray text-sm group-hover:hidden">
                {formatDuration(track.duration || 0)}
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
