import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Playlist } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Music, Home, Search, Library, Plus, Heart } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function Sidebar() {
  const [newPlaylistName, setNewPlaylistName] = useState("");
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: playlists = [] } = useQuery<Playlist[]>({
    queryKey: ["/api/playlists"],
  });

  const createPlaylistMutation = useMutation({
    mutationFn: async (name: string) => {
      const response = await apiRequest("POST", "/api/playlists", {
        name,
        description: "",
        trackIds: [],
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/playlists"] });
      setNewPlaylistName("");
      setShowCreateDialog(false);
      toast({
        title: "Playlist creada",
        description: "Tu nueva playlist se ha creado exitosamente.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "No se pudo crear la playlist",
        variant: "destructive",
      });
    },
  });

  const handleCreatePlaylist = () => {
    if (newPlaylistName.trim()) {
      createPlaylistMutation.mutate(newPlaylistName.trim());
    }
  };

  return (
    <div className="w-64 bg-black flex flex-col">
      {/* Navigation Header */}
      <div className="p-6">
        <h2 className="text-lg font-semibold text-white">Menú</h2>
      </div>
      
      {/* Navigation */}
      <nav className="flex-1 px-6">
        <div className="space-y-4">
          <Button
            variant="ghost"
            className="flex items-center text-spotify-light-gray hover:text-white transition-colors w-full justify-start p-0"
            data-testid="link-home"
          >
            <Home className="w-6 mr-4 h-5" />
            Inicio
          </Button>
          <Button
            variant="ghost"
            className="flex items-center text-spotify-light-gray hover:text-white transition-colors w-full justify-start p-0"
            data-testid="link-search"
          >
            <Search className="w-6 mr-4 h-5" />
            Buscar
          </Button>
          <Button
            variant="ghost"
            className="flex items-center text-white font-medium w-full justify-start p-0"
            data-testid="link-library"
          >
            <Library className="w-6 mr-4 h-5" />
            Tu biblioteca
          </Button>
        </div>
        
        <div className="mt-8 space-y-4">
          <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
            <DialogTrigger asChild>
              <Button
                variant="ghost"
                className="flex items-center text-spotify-light-gray hover:text-white transition-colors w-full justify-start p-0"
                data-testid="button-create-playlist"
              >
                <Plus className="w-6 mr-4 h-5" />
                Crear playlist
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-spotify-gray border-gray-600">
              <DialogHeader>
                <DialogTitle className="text-white">Crear nueva playlist</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <Input
                  placeholder="Nombre de la playlist"
                  value={newPlaylistName}
                  onChange={(e) => setNewPlaylistName(e.target.value)}
                  className="bg-spotify-dark border-gray-600 text-white"
                  data-testid="input-playlist-name"
                />
                <div className="flex space-x-2">
                  <Button 
                    onClick={handleCreatePlaylist}
                    disabled={!newPlaylistName.trim() || createPlaylistMutation.isPending}
                    className="bg-spotify-green hover:bg-green-400 text-black"
                    data-testid="button-create-playlist-submit"
                  >
                    Crear
                  </Button>
                  <Button 
                    variant="outline" 
                    onClick={() => setShowCreateDialog(false)}
                    className="border-gray-600 text-white hover:bg-spotify-dark"
                    data-testid="button-cancel-playlist"
                  >
                    Cancelar
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
          
          <Button
            variant="ghost"
            className="flex items-center text-spotify-light-gray hover:text-white transition-colors w-full justify-start p-0"
            data-testid="link-liked-songs"
          >
            <Heart className="w-6 mr-4 h-5" />
            Canciones que te gustan
          </Button>
        </div>
      </nav>
      
      {/* Recently Created Playlists */}
      <div className="px-6 pb-6">
        <div className="border-t border-spotify-gray pt-4">
          <div className="space-y-2">
            {playlists.map((playlist) => (
              <Button
                key={playlist.id}
                variant="ghost"
                className="text-spotify-light-gray hover:text-white cursor-pointer transition-colors text-sm w-full justify-start p-0 h-auto"
                data-testid={`playlist-${playlist.id}`}
              >
                {playlist.name}
              </Button>
            ))}
            {playlists.length === 0 && (
              <div className="text-spotify-light-gray text-sm">
                No hay playlists aún
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
