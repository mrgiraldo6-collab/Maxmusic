import { Track } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { 
  Play, 
  Pause, 
  SkipBack, 
  SkipForward, 
  Shuffle, 
  Repeat, 
  Volume2, 
  Heart,
  List,
  Monitor,
  Music
} from "lucide-react";
import { formatDuration } from "@/lib/audio-utils";

interface AudioPlayer {
  currentTrack: Track | null;
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  volume: number;
  isShuffleOn: boolean;
  repeatMode: "off" | "one" | "all";
  play: () => void;
  pause: () => void;
  togglePlayPause: () => void;
  previousTrack: () => void;
  nextTrack: () => void;
  toggleShuffle: () => void;
  toggleRepeat: () => void;
  setVolume: (volume: number) => void;
  seekTo: (time: number) => void;
  loadTrack: (track: Track) => void;
}

interface MusicPlayerProps {
  audioPlayer: AudioPlayer;
}

export default function MusicPlayer({ audioPlayer }: MusicPlayerProps) {
  const {
    currentTrack,
    isPlaying,
    currentTime,
    duration,
    volume,
    isShuffleOn,
    repeatMode,
    togglePlayPause,
    previousTrack,
    nextTrack,
    toggleShuffle,
    toggleRepeat,
    setVolume,
    seekTo,
  } = audioPlayer;

  const progressPercentage = duration > 0 ? (currentTime / duration) * 100 : 0;
  const volumePercentage = volume * 100;

  const handleProgressClick = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const percentage = x / rect.width;
    seekTo(percentage * duration);
  };

  const handleVolumeClick = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const percentage = x / rect.width;
    setVolume(Math.max(0, Math.min(1, percentage)));
  };

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-spotify-gray border-t border-gray-800 px-4 py-3">
      <div className="flex items-center justify-between">
        
        {/* Currently Playing */}
        <div className="flex items-center space-x-3 w-1/4">
          <div className="w-14 h-14 bg-gray-600 rounded flex items-center justify-center">
            <Music className="h-6 w-6 text-spotify-light-gray" />
          </div>
          <div className="min-w-0">
            <div className="text-white font-medium text-sm truncate">
              {currentTrack?.title || "No hay pista seleccionada"}
            </div>
            <div className="text-spotify-light-gray text-xs truncate">
              {currentTrack?.artist || ""}
            </div>
          </div>
          <Button
            variant="ghost"
            size="sm"
            className="text-spotify-light-gray hover:text-white transition-colors ml-2 p-1"
            data-testid="button-favorite-current"
          >
            <Heart className="h-4 w-4" />
          </Button>
        </div>
        
        {/* Player Controls */}
        <div className="flex flex-col items-center w-1/2">
          <div className="flex items-center space-x-4 mb-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={toggleShuffle}
              className={`transition-colors ${
                isShuffleOn ? "text-spotify-green" : "text-spotify-light-gray hover:text-white"
              }`}
              data-testid="button-shuffle"
            >
              <Shuffle className="h-4 w-4" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={previousTrack}
              className="text-spotify-light-gray hover:text-white transition-colors"
              data-testid="button-previous"
            >
              <SkipBack className="h-4 w-4" />
            </Button>
            <Button
              onClick={togglePlayPause}
              disabled={!currentTrack}
              className="bg-white text-black rounded-full w-8 h-8 flex items-center justify-center hover:scale-105 transition-transform"
              data-testid="button-play-pause"
            >
              {isPlaying ? (
                <Pause className="h-4 w-4" />
              ) : (
                <Play className="h-4 w-4 ml-0.5" />
              )}
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={nextTrack}
              className="text-spotify-light-gray hover:text-white transition-colors"
              data-testid="button-next"
            >
              <SkipForward className="h-4 w-4" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={toggleRepeat}
              className={`transition-colors ${
                repeatMode !== "off" ? "text-spotify-green" : "text-spotify-light-gray hover:text-white"
              }`}
              data-testid="button-repeat"
            >
              <Repeat className="h-4 w-4" />
            </Button>
          </div>
          
          {/* Progress Bar */}
          <div className="flex items-center space-x-2 w-full max-w-md">
            <span className="text-xs text-spotify-light-gray" data-testid="text-current-time">
              {formatDuration(currentTime)}
            </span>
            <div className="flex-1 group">
              <div 
                className="bg-gray-600 rounded-full h-1 relative cursor-pointer"
                onClick={handleProgressClick}
                data-testid="progress-bar"
              >
                <div 
                  className="bg-white rounded-full h-1 relative transition-all"
                  style={{ width: `${progressPercentage}%` }}
                >
                  <div className="absolute right-0 top-1/2 transform -translate-y-1/2 w-3 h-3 bg-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity"></div>
                </div>
              </div>
            </div>
            <span className="text-xs text-spotify-light-gray" data-testid="text-duration">
              {formatDuration(duration)}
            </span>
          </div>
        </div>
        
        {/* Volume and Other Controls */}
        <div className="flex items-center space-x-3 w-1/4 justify-end">
          <Button
            variant="ghost"
            size="sm"
            className="text-spotify-light-gray hover:text-white transition-colors"
            data-testid="button-queue"
          >
            <List className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className="text-spotify-light-gray hover:text-white transition-colors"
            data-testid="button-connect"
          >
            <Monitor className="h-4 w-4" />
          </Button>
          <div className="flex items-center space-x-2">
            <Button
              variant="ghost"
              size="sm"
              className="text-spotify-light-gray hover:text-white transition-colors"
              data-testid="button-volume"
            >
              <Volume2 className="h-4 w-4" />
            </Button>
            <div className="w-20 group">
              <div 
                className="bg-gray-600 rounded-full h-1 relative cursor-pointer"
                onClick={handleVolumeClick}
                data-testid="volume-bar"
              >
                <div 
                  className="bg-white rounded-full h-1 relative"
                  style={{ width: `${volumePercentage}%` }}
                >
                  <div className="absolute right-0 top-1/2 transform -translate-y-1/2 w-3 h-3 bg-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
