import { useState, useRef } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { CloudUpload } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { extractAudioMetadata } from "@/lib/audio-utils";

export default function FileUpload() {
  const [isDragOver, setIsDragOver] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const uploadMutation = useMutation({
    mutationFn: async (file: File) => {
      const metadata = await extractAudioMetadata(file);
      const formData = new FormData();
      formData.append("audio", file);
      formData.append("title", metadata.title);
      formData.append("artist", metadata.artist);
      formData.append("album", metadata.album);
      formData.append("duration", metadata.duration.toString());

      const response = await fetch("/api/tracks", {
        method: "POST",
        body: formData,
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || "Upload failed");
      }

      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tracks"] });
      toast({
        title: "Archivo subido",
        description: "Tu archivo de audio se ha subido exitosamente.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error al subir archivo",
        description: error.message || "No se pudo subir el archivo",
        variant: "destructive",
      });
    },
  });

  const handleFiles = async (files: FileList) => {
    setIsUploading(true);
    const audioFiles = Array.from(files).filter(file => file.type.startsWith("audio/"));
    
    if (audioFiles.length === 0) {
      toast({
        title: "Error",
        description: "Por favor selecciona archivos de audio válidos",
        variant: "destructive",
      });
      setIsUploading(false);
      return;
    }

    try {
      for (const file of audioFiles) {
        await uploadMutation.mutateAsync(file);
      }
    } catch (error) {
      console.error("Upload error:", error);
    } finally {
      setIsUploading(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    handleFiles(e.dataTransfer.files);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      handleFiles(e.target.files);
    }
  };

  return (
    <div
      className={`bg-spotify-gray rounded-lg p-8 border-2 border-dashed transition-colors ${
        isDragOver ? "border-spotify-green" : "border-gray-600"
      } hover:border-spotify-green`}
      onDrop={handleDrop}
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      data-testid="file-upload-area"
    >
      <div className="text-center">
        <CloudUpload className="mx-auto h-12 w-12 text-spotify-light-gray mb-4" />
        <p className="text-lg mb-2">
          {isUploading ? "Subiendo archivos..." : "Arrastra y suelta tus archivos de audio aquí"}
        </p>
        <p className="text-spotify-light-gray mb-4">o</p>
        <Button
          onClick={() => fileInputRef.current?.click()}
          disabled={isUploading}
          className="bg-spotify-green text-black px-6 py-2 rounded-full font-medium hover:bg-green-400 transition-colors"
          data-testid="button-select-files"
        >
          {isUploading ? "Subiendo..." : "Seleccionar archivos"}
        </Button>
        <input
          ref={fileInputRef}
          type="file"
          accept="audio/*"
          multiple
          className="hidden"
          onChange={handleFileSelect}
          data-testid="input-file"
        />
        <p className="text-xs text-spotify-light-gray mt-4">
          Formatos soportados: MP3, WAV, OGG, M4A
        </p>
      </div>
    </div>
  );
}
