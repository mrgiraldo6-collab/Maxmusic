export function formatDuration(seconds: number): string {
  if (!seconds || isNaN(seconds)) return "0:00";
  
  const minutes = Math.floor(seconds / 60);
  const remainingSeconds = Math.floor(seconds % 60);
  
  return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
}

export function extractAudioMetadata(file: File): Promise<{
  title: string;
  artist: string;
  album: string;
  duration: number;
}> {
  return new Promise((resolve) => {
    const audio = new Audio();
    const url = URL.createObjectURL(file);
    
    audio.onloadedmetadata = () => {
      // Extract basic metadata
      const filename = file.name.replace(/\.[^/.]+$/, ""); // Remove extension
      
      // Try to parse filename for artist and title (e.g., "Artist - Title.mp3")
      const parts = filename.split(" - ");
      let title = filename;
      let artist = "Unknown Artist";
      
      if (parts.length >= 2) {
        artist = parts[0].trim();
        title = parts.slice(1).join(" - ").trim();
      }
      
      resolve({
        title,
        artist,
        album: "Unknown Album",
        duration: audio.duration || 0,
      });
      
      URL.revokeObjectURL(url);
    };
    
    audio.onerror = () => {
      resolve({
        title: file.name.replace(/\.[^/.]+$/, ""),
        artist: "Unknown Artist",
        album: "Unknown Album",
        duration: 0,
      });
      URL.revokeObjectURL(url);
    };
    
    audio.src = url;
  });
}

export function createAudioVisualizer(audioElement: HTMLAudioElement, canvas: HTMLCanvasElement) {
  const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
  const analyser = audioContext.createAnalyser();
  const source = audioContext.createMediaElementSource(audioElement);
  
  source.connect(analyser);
  analyser.connect(audioContext.destination);
  
  analyser.fftSize = 256;
  const bufferLength = analyser.frequencyBinCount;
  const dataArray = new Uint8Array(bufferLength);
  
  const canvasCtx = canvas.getContext('2d')!;
  
  function draw() {
    requestAnimationFrame(draw);
    
    analyser.getByteFrequencyData(dataArray);
    
    canvasCtx.fillStyle = '#121212';
    canvasCtx.fillRect(0, 0, canvas.width, canvas.height);
    
    const barWidth = (canvas.width / bufferLength) * 2.5;
    let barHeight;
    let x = 0;
    
    for (let i = 0; i < bufferLength; i++) {
      barHeight = (dataArray[i] / 255) * canvas.height;
      
      const green = Math.floor((barHeight / canvas.height) * 255);
      canvasCtx.fillStyle = `rgb(29, ${green}, 84)`;
      canvasCtx.fillRect(x, canvas.height - barHeight, barWidth, barHeight);
      
      x += barWidth + 1;
    }
  }
  
  draw();
  
  return {
    start: () => {
      if (audioContext.state === 'suspended') {
        audioContext.resume();
      }
    },
    stop: () => {
      audioContext.suspend();
    }
  };
}
